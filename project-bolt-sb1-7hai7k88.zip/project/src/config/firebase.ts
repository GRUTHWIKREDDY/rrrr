import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getAnalytics, isSupported } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyDo2gbTy5r8pXUeNroWBHP9F-ZHkVBOEnc",
  authDomain: "fresh-ad113.firebaseapp.com",
  projectId: "fresh-ad113",
  storageBucket: "fresh-ad113.firebasestorage.app",
  messagingSenderId: "752696073473",
  appId: "1:752696073473:web:9f026991e5da51fd558f00",
  measurementId: "G-EJ3ELNFL3C"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Initialize Analytics only in production and if supported
const initAnalytics = async () => {
  if (process.env.NODE_ENV === 'production') {
    return (await isSupported()) ? getAnalytics(app) : null;
  }
  return null;
};

export const analytics = await initAnalytics();