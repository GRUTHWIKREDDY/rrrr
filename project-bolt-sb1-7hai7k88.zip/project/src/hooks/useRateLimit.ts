import { useState, useEffect } from 'react';
import { RATE_LIMIT } from '../lib/constants';

interface RateLimitState {
  attempts: number;
  lastAttempt: number;
}

export function useRateLimit(key: string) {
  const [state, setState] = useState<RateLimitState>(() => {
    const stored = localStorage.getItem(`rateLimit_${key}`);
    return stored ? JSON.parse(stored) : { attempts: 0, lastAttempt: 0 };
  });

  useEffect(() => {
    localStorage.setItem(`rateLimit_${key}`, JSON.stringify(state));
  }, [state, key]);

  const isLimited = () => {
    const now = Date.now();
    const windowExpired = now - state.lastAttempt > RATE_LIMIT.WINDOW_MS;

    if (windowExpired) {
      setState({ attempts: 0, lastAttempt: now });
      return false;
    }

    return state.attempts >= RATE_LIMIT.MAX_ATTEMPTS;
  };

  const increment = () => {
    setState(prev => ({
      attempts: prev.attempts + 1,
      lastAttempt: Date.now(),
    }));
  };

  const reset = () => {
    setState({ attempts: 0, lastAttempt: 0 });
  };

  return {
    isLimited,
    increment,
    reset,
    attemptsLeft: Math.max(0, RATE_LIMIT.MAX_ATTEMPTS - state.attempts),
    timeRemaining: Math.max(0, RATE_LIMIT.WINDOW_MS - (Date.now() - state.lastAttempt)),
  };
}