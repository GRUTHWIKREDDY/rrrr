import { useState } from 'react';
import { AuthError } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { AUTH_ERRORS } from '../lib/constants';
import { useRateLimit } from './useRateLimit';

export function useSupabaseAuth() {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const signupRateLimit = useRateLimit('signup');
  const loginRateLimit = useRateLimit('login');

  const handleAuthError = (error: AuthError) => {
    console.error('Auth error:', error);
    
    if (error.message.includes('over_email_send_rate_limit')) {
      return AUTH_ERRORS.EMAIL_RATE_LIMIT;
    }
    
    // Map Supabase errors to user-friendly messages
    switch (error.message) {
      case 'Invalid login credentials':
        return AUTH_ERRORS.INVALID_CREDENTIALS;
      case 'User already registered':
        return AUTH_ERRORS.EMAIL_IN_USE;
      case 'Rate limit exceeded':
        return AUTH_ERRORS.RATE_LIMIT;
      default:
        return error.message;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      if (loginRateLimit.isLimited()) {
        throw new Error(AUTH_ERRORS.RATE_LIMIT);
      }

      setError(null);
      setLoading(true);
      loginRateLimit.increment();
      
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      loginRateLimit.reset(); // Reset on success
    } catch (error) {
      if (error instanceof Error) {
        setError(handleAuthError(error as AuthError));
      } else {
        setError(AUTH_ERRORS.NETWORK_ERROR);
      }
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      if (signupRateLimit.isLimited()) {
        throw new Error(AUTH_ERRORS.RATE_LIMIT);
      }

      setError(null);
      setLoading(true);
      signupRateLimit.increment();
      
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
          emailRedirectTo: `${window.location.origin}/login`,
        },
      });

      if (error) throw error;
      signupRateLimit.reset(); // Reset on success
    } catch (error) {
      if (error instanceof Error) {
        setError(handleAuthError(error as AuthError));
      } else {
        setError(AUTH_ERRORS.NETWORK_ERROR);
      }
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setError(null);
      setLoading(true);
      
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message);
      } else {
        setError(AUTH_ERRORS.NETWORK_ERROR);
      }
    } finally {
      setLoading(false);
    }
  };

  return {
    error,
    loading,
    signIn,
    signUp,
    signOut,
    clearError: () => setError(null),
    attemptsLeft: {
      signup: signupRateLimit.attemptsLeft,
      login: loginRateLimit.attemptsLeft,
    },
    timeRemaining: {
      signup: signupRateLimit.timeRemaining,
      login: loginRateLimit.timeRemaining,
    },
  };
}