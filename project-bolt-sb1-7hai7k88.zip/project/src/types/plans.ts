export interface Plan {
  name: string;
  price: string;
  recommended: string;
  vegetables: number;
  weight: string;
}