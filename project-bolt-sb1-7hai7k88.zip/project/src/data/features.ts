import { Clock, Truck, Leaf, Heart, Recycle, Timer } from 'lucide-react';
import { LucideIcon } from 'lucide-react';

interface Feature {
  icon: LucideIcon;
  title: string;
}

export const features: Feature[] = [
  { icon: Clock, title: 'Delivery from 5am Daily' },
  { icon: Truck, title: 'Doorstep Delivery (Free)' },
  { icon: Leaf, title: '100% Fresh and packed' },
  { icon: Heart, title: 'Live Healthy' },
  { icon: Recycle, title: 'Ethical Sourcing' },
  { icon: Timer, title: 'Timely Delivery' },
];