export const faqs = [
  {
    question: 'What are the different weekly plans available at Sam Fresh?',
    answer: '',
  },
  {
    question: 'What vegetables are included in each plan?',
    answer: '',
  },
  {
    question: 'Can I choose the vegetables in my delivery?',
    answer: '',
  },
  {
    question: 'What if I need a custom vegetable plan?',
    answer: '',
  },
  {
    question: 'How does delivery cost fitting work?',
    answer: '',
  },
];