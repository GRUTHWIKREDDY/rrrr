import { Plan } from '../types/plans';

export const plans: Plan[] = [
  {
    name: 'Plan ₹349',
    price: '349',
    recommended: '2+1',
    vegetables: 14,
    weight: '4.5kg',
  },
  {
    name: 'Plan ₹399',
    price: '399',
    recommended: '2+1',
    vegetables: 14,
    weight: '5.5kg',
  },
  {
    name: 'Plan ₹599',
    price: '599',
    recommended: '2+3',
    vegetables: 14,
    weight: '6.5kg',
  },
  {
    name: 'Plan ₹799',
    price: '799',
    recommended: '4+2',
    vegetables: 14,
    weight: '8.5kg',
  },
  {
    name: 'Plan ₹999',
    price: '999',
    recommended: 'Large',
    vegetables: 14,
    weight: '9.5kg',
  },
];