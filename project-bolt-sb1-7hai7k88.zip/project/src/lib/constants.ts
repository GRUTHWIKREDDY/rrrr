// Auth-related constants
export const AUTH_ERRORS = {
  INVALID_CREDENTIALS: 'Invalid email or password',
  EMAIL_IN_USE: 'Email address is already in use',
  WEAK_PASSWORD: 'Password is too weak',
  NETWORK_ERROR: 'Network error. Please check your connection',
  RATE_LIMIT: 'Too many attempts. Please try again in a few minutes.',
  EMAIL_RATE_LIMIT: 'Too many signup attempts. Please try again in a few minutes.',
} as const;

// Validation constants
export const VALIDATION = {
  PASSWORD_MIN_LENGTH: 6,
  NAME_MIN_LENGTH: 2,
} as const;

// Route paths
export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  SIGNUP: '/signup',
  COMPARE_PLANS: '/compare-plans',
} as const;

// Rate limiting constants
export const RATE_LIMIT = {
  MAX_ATTEMPTS: 5,
  WINDOW_MS: 5 * 60 * 1000, // 5 minutes
} as const;