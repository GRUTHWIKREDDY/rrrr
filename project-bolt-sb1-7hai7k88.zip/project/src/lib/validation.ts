import { z } from 'zod';
import { VALIDATION } from './constants';

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(
    VALIDATION.PASSWORD_MIN_LENGTH,
    `Password must be at least ${VALIDATION.PASSWORD_MIN_LENGTH} characters`
  ),
});

export const signupSchema = loginSchema.extend({
  fullName: z.string().min(
    VALIDATION.NAME_MIN_LENGTH,
    `Full name must be at least ${VALIDATION.NAME_MIN_LENGTH} characters`
  ),
});

export type LoginForm = z.infer<typeof loginSchema>;
export type SignupForm = z.infer<typeof signupSchema>;