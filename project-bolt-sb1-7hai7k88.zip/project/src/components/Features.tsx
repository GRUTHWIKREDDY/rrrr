import React from 'react';
import { FeatureCard } from './features/FeatureCard';
import { features } from '../data/features';

export function Features() {
  return (
    <section className="bg-green-600 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-white mb-12 text-center">
          The Sam Fresh Experience
        </h2>
        <div className="grid grid-cols-3 gap-8">
          {features.map((feature) => (
            <FeatureCard
              key={feature.title}
              Icon={feature.icon}
              title={feature.title}
            />
          ))}
        </div>
      </div>
    </section>
  );
}