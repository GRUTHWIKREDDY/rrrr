import React, { useState } from 'react';
import { PlanCard } from './plans/PlanCard';
import { PlanToggle } from './plans/PlanToggle';
import { PlanDetails } from './plans/PlanDetails';
import { plans } from '../data/plans';

export function SubscriptionPlans() {
  const [planType, setPlanType] = useState<'weekly' | 'monthly'>('weekly');
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);

  const handleViewDetails = (planId: string) => {
    setSelectedPlanId(planId);
  };

  if (selectedPlanId) {
    return <PlanDetails planId={selectedPlanId} onClose={() => setSelectedPlanId(null)} />;
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">
          SELECT A PLAN, SUITS YOUR FAMILY
        </h2>
        <PlanToggle activeType={planType} onToggle={setPlanType} />
        <div className="grid grid-cols-5 gap-6">
          {plans.map((plan) => (
            <PlanCard 
              key={plan.name} 
              plan={plan} 
              onViewDetails={handleViewDetails}
            />
          ))}
        </div>
      </div>
    </section>
  );
}