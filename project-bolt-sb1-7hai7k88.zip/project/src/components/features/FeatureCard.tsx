import React from 'react';
import { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  Icon: LucideIcon;
  title: string;
}

export function FeatureCard({ Icon, title }: FeatureCardProps) {
  return (
    <div className="flex flex-col items-center">
      <Icon className="text-white mb-4" size={40} />
      <p className="text-white text-center font-medium">{title}</p>
    </div>
  );
}