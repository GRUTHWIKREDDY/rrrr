import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogIn, UserPlus, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { AuthLayout } from './AuthLayout';
import { useForm } from '../../hooks/useForm';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { z } from 'zod';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type LoginForm = z.infer<typeof loginSchema>;

export function LoginPage() {
  const { signIn, error, clearError, user } = useAuth();
  const navigate = useNavigate();

  const { values, errors, handleChange, handleSubmit, isValid } = useForm<LoginForm>({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: loginSchema,
    onSubmit: async (values) => {
      await signIn(values.email, values.password);
    },
  });

  useEffect(() => {
    if (user) {
      navigate('/');
    }
    return () => {
      clearError();
    };
  }, [user, navigate, clearError]);

  return (
    <AuthLayout
      title="Welcome back!"
      subtitle="Sign in to your account to continue"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-md p-4 flex items-start gap-3">
            <AlertCircle className="text-red-500 shrink-0 mt-0.5" size={20} />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <Input
          id="email"
          name="email"
          type="email"
          label="Email address"
          value={values.email}
          onChange={handleChange}
          error={errors.email}
        />

        <Input
          id="password"
          name="password"
          type="password"
          label="Password"
          value={values.password}
          onChange={handleChange}
          error={errors.password}
        />

        <Button type="submit" disabled={!isValid} icon={LogIn}>
          Sign in
        </Button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-gray-50 text-gray-500">
              New to Sam Fresh?
            </span>
          </div>
        </div>

        <Link to="/signup">
          <Button variant="secondary" icon={UserPlus}>
            Create an account
          </Button>
        </Link>
      </form>
    </AuthLayout>
  );
}