import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogIn, UserPlus, AlertCircle, Info } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { AuthLayout } from './AuthLayout';
import { useForm } from '../../hooks/useForm';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { signupSchema } from '../../lib/validation';
import type { SignupForm } from '../../lib/validation';

export function SignupPage() {
  const { signUp, error, clearError, user } = useAuth();
  const navigate = useNavigate();

  const { values, errors, handleChange, handleSubmit, isValid } = useForm<SignupForm>({
    initialValues: {
      email: '',
      password: '',
      fullName: '',
    },
    validationSchema: signupSchema,
    onSubmit: async (values) => {
      await signUp(values.email, values.password, values.fullName);
    },
  });

  useEffect(() => {
    if (user) {
      navigate('/');
    }
    return () => {
      clearError();
    };
  }, [user, navigate, clearError]);

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Start your journey with Sam Fresh"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-md p-4 flex items-start gap-3">
            <AlertCircle className="text-red-500 shrink-0 mt-0.5" size={20} />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <div className="bg-blue-50 border border-blue-200 rounded-md p-4 flex items-start gap-3">
          <Info className="text-blue-500 shrink-0 mt-0.5" size={20} />
          <p className="text-sm text-blue-600">
            After signing up, you'll receive a confirmation email. Please check your inbox and follow the instructions to verify your account.
          </p>
        </div>

        <Input
          id="fullName"
          name="fullName"
          type="text"
          label="Full Name"
          value={values.fullName}
          onChange={handleChange}
          error={errors.fullName}
        />

        <Input
          id="email"
          name="email"
          type="email"
          label="Email address"
          value={values.email}
          onChange={handleChange}
          error={errors.email}
        />

        <Input
          id="password"
          name="password"
          type="password"
          label="Password"
          value={values.password}
          onChange={handleChange}
          error={errors.password}
        />

        <Button type="submit" disabled={!isValid} icon={UserPlus}>
          Create account
        </Button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-gray-50 text-gray-500">
              Already have an account?
            </span>
          </div>
        </div>

        <Link to="/login">
          <Button variant="secondary" icon={LogIn}>
            Sign in to your account
          </Button>
        </Link>
      </form>
    </AuthLayout>
  );
}