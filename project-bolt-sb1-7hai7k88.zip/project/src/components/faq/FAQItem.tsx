import React from 'react';
import { ChevronDown } from 'lucide-react';

interface FAQItemProps {
  question: string;
  isOpen: boolean;
  onClick: () => void;
}

export function FAQItem({ question, isOpen, onClick }: FAQItemProps) {
  return (
    <button
      onClick={onClick}
      className="w-full p-4 bg-gray-100 rounded-lg flex items-center justify-between hover:bg-gray-200 transition-colors"
    >
      <span className="font-medium text-left">{question}</span>
      <ChevronDown
        size={20}
        className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`}
      />
    </button>
  );
}