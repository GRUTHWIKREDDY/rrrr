import React, { useState } from 'react';
import { FAQItem } from './faq/FAQItem';
import { faqs } from '../data/faqs';

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-16">
      <div className="max-w-3xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">FAQ's</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <FAQItem
              key={faq.question}
              question={faq.question}
              isOpen={openIndex === index}
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
            />
          ))}
        </div>
        <div className="text-center mt-8">
          <button className="px-6 py-2 bg-green-600 text-white rounded-full">
            More FAQ's
          </button>
        </div>
      </div>
    </section>
  );
}