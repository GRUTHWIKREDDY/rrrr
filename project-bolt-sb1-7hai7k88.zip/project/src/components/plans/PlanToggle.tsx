import React from 'react';

interface PlanToggleProps {
  activeType: 'weekly' | 'monthly';
  onToggle: (type: 'weekly' | 'monthly') => void;
}

export function PlanToggle({ activeType, onToggle }: PlanToggleProps) {
  return (
    <div className="flex justify-center gap-4 mb-8">
      <button
        onClick={() => onToggle('weekly')}
        className={`px-6 py-2 rounded-full ${
          activeType === 'weekly'
            ? 'bg-green-600 text-white'
            : 'bg-gray-200 text-gray-700'
        }`}
      >
        WEEKLY
      </button>
      <button
        onClick={() => onToggle('monthly')}
        className={`px-6 py-2 rounded-full ${
          activeType === 'monthly'
            ? 'bg-green-600 text-white'
            : 'bg-gray-200 text-gray-700'
        }`}
      >
        MONTHLY
      </button>
    </div>
  );
}