import React from 'react';
import { Check } from 'lucide-react';

interface WhyChoosePlanProps {
  planId: string;
}

export function WhyChoosePlan({ planId }: WhyChoosePlanProps) {
  return (
    <div className="mt-16">
      <h2 className="text-2xl font-bold mb-8">Why Choose Plan {planId}?</h2>
      <div className="grid grid-cols-2 gap-8">
        <div>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Check className="text-green-600 mt-1" />
              <div>
                <h3 className="font-semibold">Convenient Weekly Deliveries</h3>
                <p className="text-gray-600">Fresh vegetables delivered to your doorstep every week</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-green-600 mt-1" />
              <div>
                <h3 className="font-semibold">High-Quality Produce</h3>
                <p className="text-gray-600">Sourced directly from farmers and wholesalers to ensure freshness and quality</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-green-600 mt-1" />
              <div>
                <h3 className="font-semibold">Diverse Selection</h3>
                <p className="text-gray-600">13 varieties of vegetables to meet all your dietary needs</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-green-600 mt-1" />
              <div>
                <h3 className="font-semibold">Affordable Pricing</h3>
                <p className="text-gray-600">Get premium vegetables at an economical price of ₹399 per week (plus/month)</p>
              </div>
            </div>
          </div>
        </div>
        <div>
          <img
            src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80"
            alt="Fresh vegetables"
            className="w-full h-full object-cover rounded-lg"
          />
        </div>
      </div>
    </div>
  );
}