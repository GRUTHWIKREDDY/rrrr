import React from 'react';

const otherVegetables = [
  { name: 'Cabbage', image: 'https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?auto=format&fit=crop&q=80&w=200' },
  { name: 'Cauliflower', image: 'https://images.unsplash.com/photo-1568584711075-3d021a7c3ca3?auto=format&fit=crop&q=80&w=200' },
  { name: 'Brinjal', image: 'https://images.unsplash.com/photo-1528826007177-f38517ce9a8f?auto=format&fit=crop&q=80&w=200' },
  { name: 'Bhindi', image: 'https://images.unsplash.com/photo-1425543103986-22abb7d7e8d2?auto=format&fit=crop&q=80&w=200' },
  { name: 'Carrot', image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&q=80&w=200' },
  { name: 'Beans', image: 'https://images.unsplash.com/photo-1567375698348-5d9d5ae99de0?auto=format&fit=crop&q=80&w=200' },
];

export function OtherVegetables() {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4 text-center">Other Vegetables</h3>
      <p className="text-center text-gray-600 mb-4">(7 VARIETIES INCLUDED)</p>
      <p className="text-center text-sm text-gray-500 mb-8">
        Each week, we will deliver any 7 vegetables from the 25 varieties listed below.
        <br />
        (You can choose up to 4 vegetables that you don't want in any single lot)
      </p>
      <div className="grid grid-cols-6 gap-6">
        {otherVegetables.map((veg) => (
          <div key={veg.name} className="text-center">
            <div className="aspect-square mb-2 rounded-lg overflow-hidden">
              <img src={veg.image} alt={veg.name} className="w-full h-full object-cover" />
            </div>
            <p className="font-medium">{veg.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
}