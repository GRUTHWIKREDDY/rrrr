import React from 'react';
import { PlanHeader } from './PlanHeader';
import { EssentialVegetables } from './EssentialVegetables';
import { OtherVegetables } from './OtherVegetables';
import { WhyChoosePlan } from './WhyChoosePlan';
import { PlanToggle } from './PlanToggle';

interface PlanDetailsProps {
  planId: string;
  onClose: () => void;
}

export function PlanDetails({ planId, onClose }: PlanDetailsProps) {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <button onClick={onClose} className="text-gray-600 hover:text-gray-800">
            ← Back to Plans
          </button>
          <PlanToggle activeType="weekly" onToggle={() => {}} />
        </div>
        
        <PlanHeader planId={planId} />
        
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Plan Details</h2>
          <p className="text-center text-gray-600 mb-12">(Approx Weight: 4.5kgs)</p>
          
          <EssentialVegetables />
          
          <div className="flex justify-center my-8">
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-2xl text-gray-400">
              +
            </div>
          </div>
          
          <OtherVegetables />
          
          <div className="mt-12 flex justify-center">
            <button className="bg-green-600 text-white px-8 py-3 rounded-full hover:bg-green-700 transition-colors">
              Subscribe to {planId} Plan
            </button>
          </div>
        </div>
        
        <WhyChoosePlan planId={planId} />
        
        <div className="mt-12 text-center">
          <h3 className="text-xl font-semibold mb-4">
            Start enjoying fresh, nutritious vegetables with {planId} today!
          </h3>
          <button className="bg-green-600 text-white px-8 py-3 rounded-full hover:bg-green-700 transition-colors">
            Subscribe to {planId} Plan
          </button>
        </div>
      </div>
    </div>
  );
}