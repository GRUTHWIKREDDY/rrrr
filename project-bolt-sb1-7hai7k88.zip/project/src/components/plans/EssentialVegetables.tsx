import React from 'react';

const essentialVegetables = [
  { name: 'Tomato', quantity: '1 Kg', image: 'https://images.unsplash.com/photo-1546470427-1ec6068c9885?auto=format&fit=crop&q=80&w=200' },
  { name: 'Potatoes', quantity: '500 gms', image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&q=80&w=200' },
  { name: 'Coriander', quantity: '1 bunch', image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&q=80&w=200' },
  { name: 'Green Chilli', quantity: '100 gms', image: 'https://images.unsplash.com/photo-1601648764658-cf37e8c89b70?auto=format&fit=crop&q=80&w=200' },
  { name: 'Curry Leaf', quantity: '50 gms', image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&q=80&w=200' },
  { name: 'Ginger', quantity: '100 gms', image: 'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?auto=format&fit=crop&q=80&w=200' },
];

export function EssentialVegetables() {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4 text-center">Essential Vegetables</h3>
      <p className="text-center text-gray-600 mb-8">(All Included)</p>
      <div className="grid grid-cols-6 gap-6">
        {essentialVegetables.map((veg) => (
          <div key={veg.name} className="text-center">
            <div className="aspect-square mb-2 rounded-lg overflow-hidden">
              <img src={veg.image} alt={veg.name} className="w-full h-full object-cover" />
            </div>
            <p className="font-medium">{veg.name}</p>
            <p className="text-sm text-gray-600">{veg.quantity}</p>
          </div>
        ))}
      </div>
    </div>
  );
}