import React from 'react';
import { Users } from 'lucide-react';

interface PlanHeaderProps {
  planId: string;
}

export function PlanHeader({ planId }: PlanHeaderProps) {
  return (
    <div className="text-center">
      <div className="flex justify-center mb-4">
        <Users className="text-green-600" size={48} />
      </div>
      <h1 className="text-3xl font-bold mb-4">Plan {planId}</h1>
      <p className="text-gray-600 max-w-2xl mx-auto">
        Experience the freshest, highest quality vegetables with SAM Fresh. Plan {planId} is ideal for a 2+1 family, and offers 13 varieties 
        of vegetables, approximately 4.5kgs. Fresh fresh veggies delivered to your doorstep weekly.
      </p>
    </div>
  );
}