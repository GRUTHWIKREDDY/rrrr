import React from 'react';
import { Plan } from '../../types/plans';

interface PlanCardProps {
  plan: Plan;
  onViewDetails: (planId: string) => void;
}

export function PlanCard({ plan, onViewDetails }: PlanCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="font-bold text-xl mb-4">{plan.name}</h3>
      <div className="mb-4">
        <p className="text-sm text-gray-600">Recommended for</p>
        <p className="font-medium">{plan.recommended}</p>
      </div>
      <div className="mb-4">
        <p className="text-sm text-gray-600">No. of vegetables</p>
        <p className="font-medium">{plan.vegetables}</p>
      </div>
      <div className="mb-6">
        <p className="text-sm text-gray-600">Approx Weight</p>
        <p className="font-medium">{plan.weight}</p>
      </div>
      <button 
        onClick={() => onViewDetails(plan.price)}
        className="w-full py-2 border-2 border-green-600 text-green-600 rounded-full hover:bg-green-50 transition-colors"
      >
        View
      </button>
    </div>
  );
}